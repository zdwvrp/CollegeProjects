Note: jdk version 17 was used to compile and run this project.

Syntax for running the Server:

    javac Server.java
    java Server