Note: jdk version 17 was used to compile and run this project.
Note: The port for this project is 17050.

Syntax for running the Client:

    javac Client.java
    java Client [ip address] [port]